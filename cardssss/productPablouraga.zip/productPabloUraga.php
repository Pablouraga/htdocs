<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product</title>
</head>

<body>
    <form method="get" action="processPabloUraga.php">
        Codigo <input type="text" name="code" id="code"><br><br>

        Nombre <input type="text" name="name" id="name"><br><br>

        Precio <input type="text" name="price" id="price"><br><br>

        Descripcion<br><input type="text" name="description" rows="10" cols="50"></textarea><br><br>

        Fabricante <input type="text" name="maker" id="maker"><br><br>

        Fecha de adquisicion <input type="text" name="adquisitionDate" id="adquisitionDate"><br><br>

        <input type="submit" value="Enviar">

    </form>
</body>

</html>